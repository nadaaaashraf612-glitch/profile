import { type ReactNode } from "react";
import { useReveal } from "../hooks/useReveal";
import { cn } from "../utils/cn";

export function Reveal({
  children,
  className,
  delay = 0,
  as: Component = "div",
}: {
  children: ReactNode;
  className?: string;
  delay?: number;
  as?: "div" | "span" | "li";
}) {
  const { ref, visible } = useReveal();
  return (
    <Component
      ref={ref as never}
      className={cn("reveal", visible && "reveal-visible", className)}
      style={{ transitionDelay: visible ? `${delay}ms` : "0ms" }}
    >
      {children}
    </Component>
  );
}
