import { type ReactNode } from "react";
import { cn } from "../utils/cn";

export function Kicker({
  children,
  tone = "dark",
  className,
}: {
  children: ReactNode;
  tone?: "dark" | "light";
  className?: string;
}) {
  return (
    <div
      className={cn(
        "flex items-center gap-3 text-[11px] font-medium uppercase tracking-[0.35em]",
        tone === "dark" ? "text-black/60" : "text-white/60",
        className
      )}
    >
      <span className={cn("h-px w-8", tone === "dark" ? "bg-black/40" : "bg-white/40")} />
      {children}
    </div>
  );
}

export function PageMeta({
  index,
  label,
  tone = "dark",
}: {
  index: string;
  label: string;
  tone?: "dark" | "light";
}) {
  return (
    <div
      className={cn(
        "pointer-events-none absolute inset-x-0 bottom-0 z-10 flex items-center justify-between px-6 py-5 text-[10px] font-medium uppercase tracking-[0.3em] sm:px-10 lg:px-16",
        tone === "dark" ? "text-black/40" : "text-white/40"
      )}
    >
      <span>PUIUX — Company Profile</span>
      <span className="hidden sm:inline">{label}</span>
      <span>{index} / 17</span>
    </div>
  );
}

export function GlassCard({
  children,
  className,
  tone = "light",
}: {
  children: ReactNode;
  className?: string;
  tone?: "light" | "dark";
}) {
  return (
    <div
      className={cn(
        "relative overflow-hidden rounded-2xl border backdrop-blur-xl",
        tone === "light"
          ? "border-black/10 bg-white/50 shadow-[0_8px_40px_rgba(0,0,0,0.06)]"
          : "border-white/15 bg-white/[0.06] shadow-[0_8px_40px_rgba(0,0,0,0.3)]",
        className
      )}
    >
      {children}
    </div>
  );
}

export function PlaceholderField({
  label,
  tone = "dark",
}: {
  label: string;
  tone?: "dark" | "light";
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-2 border-b border-dashed pb-0.5 text-sm italic",
        tone === "dark" ? "border-black/30 text-black/40" : "border-white/30 text-white/50"
      )}
    >
      {label}
    </span>
  );
}

export function TagPill({ children, tone = "dark" }: { children: ReactNode; tone?: "dark" | "light" }) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full border px-3 py-1 text-[11px] font-medium uppercase tracking-[0.1em]",
        tone === "dark" ? "border-black/15 text-black/70" : "border-white/20 text-white/70"
      )}
    >
      {children}
    </span>
  );
}

export function Divider({ tone = "dark", className }: { tone?: "dark" | "light"; className?: string }) {
  return <div className={cn("h-px w-full", tone === "dark" ? "bg-black/10" : "bg-white/15", className)} />;
}

export function BigIndex({ n, tone = "dark" }: { n: string; tone?: "dark" | "light" }) {
  return (
    <span
      className={cn(
        "font-display text-xs font-medium tabular-nums tracking-[0.2em]",
        tone === "dark" ? "text-black/40" : "text-white/40"
      )}
    >
      {n}
    </span>
  );
}
