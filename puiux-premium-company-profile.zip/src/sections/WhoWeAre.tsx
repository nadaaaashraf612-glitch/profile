import { Reveal } from "../components/Reveal";
import { GlassCard, Kicker, PageMeta } from "../components/ui";

export function WhoWeAre() {
  return (
    <section id="who-we-are" className="relative flex min-h-screen flex-col justify-center overflow-hidden bg-black px-6 py-28 text-white sm:px-10 lg:px-16">
      <div className="pointer-events-none absolute inset-0 opacity-[0.08]">
        <div className="h-full w-full bg-[linear-gradient(to_right,white_1px,transparent_1px),linear-gradient(to_bottom,white_1px,transparent_1px)] bg-[size:64px_64px]" />
      </div>

      <div className="relative grid grid-cols-1 gap-16 lg:grid-cols-12">
        <div className="lg:col-span-5">
          <Reveal>
            <Kicker tone="light">Who We Are</Kicker>
          </Reveal>
          <Reveal delay={100}>
            <h2 className="mt-8 font-display text-5xl font-medium leading-[1.05] tracking-tight sm:text-6xl">
              A studio built for software that matters.
            </h2>
          </Reveal>
          <Reveal delay={200} className="mt-8 max-w-md space-y-5 text-base leading-relaxed text-white/70">
            <p>
              PUIUX is a software and digital product development studio. We partner with
              founders, product teams and enterprises to design and build web platforms, mobile
              applications and custom software.
            </p>
            <p>
              Our work sits across three disciplines — product design, engineering and strategy —
              brought together under one roof so nothing gets lost between teams.
            </p>
          </Reveal>
        </div>

        <div className="lg:col-span-6 lg:col-start-7">
          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
            <Reveal delay={150}>
              <GlassCard tone="dark" className="h-full p-7">
                <p className="font-display text-sm uppercase tracking-[0.25em] text-white/50">Positioning</p>
                <p className="mt-4 text-lg leading-snug text-white/90">
                  A design-led digital product partner, not a feature factory.
                </p>
              </GlassCard>
            </Reveal>
            <Reveal delay={250}>
              <GlassCard tone="dark" className="h-full p-7">
                <p className="font-display text-sm uppercase tracking-[0.25em] text-white/50">Value Proposition</p>
                <p className="mt-4 text-lg leading-snug text-white/90">
                  Business understanding, UX craft and technical execution, in one team.
                </p>
              </GlassCard>
            </Reveal>
            <Reveal delay={350} className="sm:col-span-2">
              <GlassCard tone="dark" className="p-7">
                <p className="font-display text-sm uppercase tracking-[0.25em] text-white/50">How We Engage</p>
                <div className="mt-5 grid grid-cols-1 gap-5 sm:grid-cols-3">
                  {["Embedded product teams", "Fixed-scope builds", "Long-term platform partners"].map((t) => (
                    <div key={t} className="border-t border-white/15 pt-3 text-sm text-white/75">
                      {t}
                    </div>
                  ))}
                </div>
              </GlassCard>
            </Reveal>
          </div>
        </div>
      </div>

      <PageMeta index="03" label="Who We Are" tone="light" />
    </section>
  );
}
