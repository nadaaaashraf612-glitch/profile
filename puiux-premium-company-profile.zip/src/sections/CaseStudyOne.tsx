import { Reveal } from "../components/Reveal";
import { Kicker, PageMeta, TagPill, Divider } from "../components/ui";

export function CaseStudyOne() {
  return (
    <section id="case-01" className="relative flex min-h-screen flex-col justify-center bg-[#fafaf8] px-6 py-28 text-black sm:px-10 lg:px-16">
      <div className="grid grid-cols-1 gap-14 lg:grid-cols-12">
        <div className="lg:col-span-6">
          <Reveal>
            <Kicker>Case Study — 01</Kicker>
            <div className="mt-6 flex items-center gap-3">
              <TagPill>Illustrative Placeholder</TagPill>
              <TagPill>Web Platform</TagPill>
            </div>
            <h2 className="mt-6 font-display text-4xl font-medium leading-tight tracking-tight sm:text-5xl">
              Enterprise SaaS Dashboard
            </h2>
          </Reveal>

          <Reveal delay={150} className="mt-10 space-y-8">
            <div>
              <p className="font-display text-xs uppercase tracking-[0.3em] text-black/40">Challenge</p>
              <p className="mt-3 max-w-md text-base leading-relaxed text-black/70">
                A growing operations team needed a way to monitor and act on complex data without
                relying on spreadsheets and disconnected tools.
              </p>
            </div>
            <div>
              <p className="font-display text-xs uppercase tracking-[0.3em] text-black/40">Solution</p>
              <p className="mt-3 max-w-md text-base leading-relaxed text-black/70">
                A unified dashboard platform consolidating key metrics, workflows and reporting
                into one clear, role-based interface.
              </p>
            </div>
            <Divider className="max-w-md" />
            <div className="grid max-w-md grid-cols-2 gap-6">
              <div>
                <p className="font-display text-xs uppercase tracking-[0.3em] text-black/40">Scope</p>
                <p className="mt-3 text-sm leading-relaxed text-black/70">
                  UX research, design system, frontend &amp; backend engineering.
                </p>
              </div>
              <div>
                <p className="font-display text-xs uppercase tracking-[0.3em] text-black/40">Outcome</p>
                <p className="mt-3 text-sm italic leading-relaxed text-black/40">
                  Verified results pending client approval for publication.
                </p>
              </div>
            </div>
          </Reveal>
        </div>

        <div className="lg:col-span-6">
          <Reveal delay={200} className="relative">
            <div className="absolute -inset-4 -z-10 rounded-3xl border border-black/10" />
            <div className="overflow-hidden rounded-2xl border border-black/10 bg-white shadow-[0_30px_80px_rgba(0,0,0,0.12)]">
              <img
                src="/images/case-study-1.jpg"
                alt="Enterprise SaaS dashboard — illustrative placeholder mockup"
                className="h-full w-full object-cover grayscale"
              />
            </div>
          </Reveal>
        </div>
      </div>

      <PageMeta index="12" label="Case Study — 01" />
    </section>
  );
}
