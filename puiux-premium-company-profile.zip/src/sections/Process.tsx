import { Reveal } from "../components/Reveal";
import { processSteps } from "../data/content";
import { Kicker, PageMeta } from "../components/ui";

export function Process() {
  return (
    <section id="process" className="relative flex min-h-screen flex-col justify-center bg-[#fafaf8] px-6 py-28 text-black sm:px-10 lg:px-16">
      <Reveal>
        <Kicker>How We Work</Kicker>
        <h2 className="mt-8 max-w-2xl font-display text-5xl font-medium leading-tight tracking-tight sm:text-6xl">
          A disciplined process, end to end.
        </h2>
      </Reveal>

      <div className="mt-16 flex flex-col">
        {processSteps.map((step, i) => (
          <Reveal key={step.no} delay={i * 80}>
            <div className="group grid grid-cols-[3rem_1fr] items-start gap-4 border-t border-black/10 py-6 sm:grid-cols-[6rem_minmax(0,16rem)_1fr] sm:items-center sm:gap-8">
              <span className="font-display text-sm text-black/30">{step.no}</span>
              <h3 className="font-display text-2xl font-medium tracking-tight transition group-hover:translate-x-1 sm:text-3xl">
                {step.title}
              </h3>
              <p className="max-w-xl text-sm leading-relaxed text-black/60">{step.copy}</p>
            </div>
          </Reveal>
        ))}
        <div className="border-t border-black/10" />
      </div>

      <PageMeta index="08" label="How We Work" />
    </section>
  );
}
