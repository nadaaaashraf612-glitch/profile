import { Reveal } from "../components/Reveal";
import { services } from "../data/content";
import { Kicker, PageMeta, TagPill, Divider } from "../components/ui";

export function Services() {
  return (
    <section id="services" className="relative flex min-h-screen flex-col justify-center bg-[#fafaf8] px-6 py-28 text-black sm:px-10 lg:px-16">
      <div className="flex flex-col gap-6 sm:flex-row sm:items-end sm:justify-between">
        <Reveal>
          <Kicker>Our Services</Kicker>
          <h2 className="mt-8 max-w-xl font-display text-5xl font-medium leading-tight tracking-tight sm:text-6xl">
            Full-cycle digital product capability.
          </h2>
        </Reveal>
        <Reveal delay={150} className="max-w-xs text-sm leading-relaxed text-black/60">
          From early product strategy to interface design, engineering and long-term support.
        </Reveal>
      </div>

      <Divider className="mt-12" />

      <div className="grid grid-cols-1 divide-y divide-black/10 sm:grid-cols-2 lg:grid-cols-3 lg:divide-x lg:divide-y-0">
        {services.map((s, i) => (
          <Reveal key={s.no} delay={(i % 3) * 100} className="group py-10 lg:px-8 lg:first:pl-0">
            <div className="flex items-start justify-between">
              <span className="font-display text-sm text-black/30">{s.no}</span>
              <span className="h-2 w-2 rounded-full bg-black/10 transition group-hover:bg-black" />
            </div>
            <h3 className="mt-6 font-display text-2xl font-medium tracking-tight">{s.title}</h3>
            <p className="mt-3 text-sm leading-relaxed text-black/60">{s.copy}</p>
            <div className="mt-5 flex flex-wrap gap-2">
              {s.tags.map((t) => (
                <TagPill key={t}>{t}</TagPill>
              ))}
            </div>
          </Reveal>
        ))}
      </div>

      <PageMeta index="06" label="Our Services" />
    </section>
  );
}
