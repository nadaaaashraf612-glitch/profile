import { Reveal } from "../components/Reveal";
import { whyPoints } from "../data/content";
import { Kicker, PageMeta, Divider } from "../components/ui";

export function Why() {
  return (
    <section id="why" className="relative flex min-h-screen flex-col justify-center bg-[#fafaf8] px-6 py-28 text-black sm:px-10 lg:px-16">
      <Reveal>
        <Kicker>Why PUIUX</Kicker>
        <h2 className="mt-8 max-w-2xl font-display text-5xl font-medium leading-tight tracking-tight sm:text-6xl">
          What sets the work apart.
        </h2>
      </Reveal>

      <Divider className="mt-12" />

      <div className="grid grid-cols-1 sm:grid-cols-2">
        {whyPoints.map((p, i) => (
          <Reveal key={p.no} delay={i * 100}>
            <div className="grid grid-cols-[4rem_1fr] gap-4 border-b border-black/10 py-10 pr-6 sm:odd:border-r sm:odd:pr-10">
              <span className="font-display text-4xl font-semibold text-black/15">{p.no}</span>
              <div>
                <h3 className="font-display text-2xl font-medium tracking-tight">{p.title}</h3>
                <p className="mt-3 max-w-sm text-sm leading-relaxed text-black/60">{p.copy}</p>
              </div>
            </div>
          </Reveal>
        ))}
      </div>

      <PageMeta index="14" label="Why PUIUX" />
    </section>
  );
}
