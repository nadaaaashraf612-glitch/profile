import { Reveal } from "../components/Reveal";
import { values } from "../data/content";
import { Kicker, PageMeta, Divider } from "../components/ui";

export function VisionMissionValues() {
  return (
    <section id="vmv" className="relative flex min-h-screen flex-col justify-center bg-[#fafaf8] px-6 py-28 text-black sm:px-10 lg:px-16">
      <Reveal>
        <Kicker>Vision, Mission &amp; Values</Kicker>
      </Reveal>

      <div className="mt-12 grid grid-cols-1 gap-12 lg:grid-cols-2">
        <Reveal delay={100} className="border-l border-black/15 pl-6">
          <p className="font-display text-xs uppercase tracking-[0.3em] text-black/40">Vision</p>
          <p className="mt-4 font-display text-3xl font-medium leading-snug tracking-tight sm:text-4xl">
            A world where good software is the standard, not the exception.
          </p>
        </Reveal>
        <Reveal delay={200} className="border-l border-black/15 pl-6">
          <p className="font-display text-xs uppercase tracking-[0.3em] text-black/40">Mission</p>
          <p className="mt-4 font-display text-3xl font-medium leading-snug tracking-tight sm:text-4xl">
            To help businesses design, build and evolve digital products with clarity and craft.
          </p>
        </Reveal>
      </div>

      <Divider className="my-16" />

      <div className="grid grid-cols-1 gap-x-10 gap-y-12 sm:grid-cols-2 lg:grid-cols-4">
        {values.map((v, i) => (
          <Reveal key={v.no} delay={i * 100}>
            <p className="font-display text-sm text-black/30">{v.no}</p>
            <h3 className="mt-4 font-display text-2xl font-medium tracking-tight">{v.title}</h3>
            <p className="mt-3 text-sm leading-relaxed text-black/60">{v.copy}</p>
          </Reveal>
        ))}
      </div>

      <PageMeta index="04" label="Vision, Mission & Values" />
    </section>
  );
}
