import { Reveal } from "../components/Reveal";
import { expertise } from "../data/content";
import { GlassCard, Kicker, PageMeta, TagPill } from "../components/ui";

export function Expertise() {
  return (
    <section id="expertise" className="relative flex min-h-screen flex-col justify-center overflow-hidden bg-black px-6 py-28 text-white sm:px-10 lg:px-16">
      <div className="pointer-events-none absolute -right-32 -top-32 h-[28rem] w-[28rem] rounded-full border border-white/10" />
      <div className="pointer-events-none absolute -right-10 top-10 h-[20rem] w-[20rem] rounded-full border border-white/10" />

      <div className="relative grid grid-cols-1 gap-12 lg:grid-cols-12">
        <div className="lg:col-span-5">
          <Reveal>
            <Kicker tone="light">Our Expertise</Kicker>
          </Reveal>
          <Reveal delay={100}>
            <h2 className="mt-8 font-display text-4xl font-medium leading-tight tracking-tight sm:text-5xl">
              Technology chosen for reliability, not trend.
            </h2>
          </Reveal>
          <Reveal delay={200} className="mt-6 max-w-sm text-sm leading-relaxed text-white/60">
            We select tools based on the needs of each product — favoring proven, well-supported
            technology that scales cleanly over time.
          </Reveal>
        </div>

        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:col-span-7">
          {expertise.map((group, i) => (
            <Reveal key={group.group} delay={i * 100}>
              <GlassCard tone="dark" className="h-full p-7">
                <p className="font-display text-xs uppercase tracking-[0.3em] text-white/45">{group.group}</p>
                <div className="mt-5 flex flex-wrap gap-2">
                  {group.items.map((item) => (
                    <TagPill key={item} tone="light">
                      {item}
                    </TagPill>
                  ))}
                </div>
              </GlassCard>
            </Reveal>
          ))}
        </div>
      </div>

      <PageMeta index="09" label="Our Expertise" tone="light" />
    </section>
  );
}
