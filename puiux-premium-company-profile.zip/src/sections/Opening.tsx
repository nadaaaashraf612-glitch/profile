import { Reveal } from "../components/Reveal";
import { Kicker, PageMeta } from "../components/ui";

export function Opening() {
  return (
    <section id="opening" className="relative flex min-h-screen flex-col justify-center bg-[#fafaf8] px-6 py-28 text-black sm:px-10 lg:px-16">
      <div className="grid grid-cols-1 gap-10 lg:grid-cols-12">
        <div className="lg:col-span-4">
          <Reveal>
            <Kicker>Opening Statement</Kicker>
          </Reveal>
          <Reveal delay={100} className="mt-8 max-w-xs text-sm leading-relaxed text-black/60">
            Technology moves fast. Good products are still built slowly — through understanding,
            iteration and care.
          </Reveal>
        </div>

        <div className="lg:col-span-8">
          <Reveal delay={80}>
            <h2 className="font-display text-[11vw] font-medium leading-[0.95] tracking-tight sm:text-[6.5vw] lg:text-[5.2vw]">
              We design and build software that{" "}
              <span className="text-black/30">people actually want to use</span> — and businesses
              rely on.
            </h2>
          </Reveal>

          <Reveal delay={200} className="mt-14 grid max-w-2xl grid-cols-1 gap-8 border-t border-black/10 pt-10 sm:grid-cols-2">
            <p className="text-base leading-relaxed text-black/70">
              PUIUX exists at the intersection of design and engineering — turning ambiguous
              problems into clear, well-crafted digital products.
            </p>
            <p className="text-base leading-relaxed text-black/70">
              Every engagement starts with the business, not the interface. The result is software
              that looks considered because it is considered.
            </p>
          </Reveal>
        </div>
      </div>

      <PageMeta index="02" label="Opening Statement" />
    </section>
  );
}
