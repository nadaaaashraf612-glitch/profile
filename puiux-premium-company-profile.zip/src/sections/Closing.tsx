import { useParallax } from "../hooks/useReveal";
import { Reveal } from "../components/Reveal";
import { PageMeta } from "../components/ui";

export function Closing() {
  const bg = useParallax<HTMLDivElement>(0.1);

  return (
    <section id="closing" className="relative flex min-h-screen flex-col items-center justify-center overflow-hidden bg-black px-6 py-28 text-center text-white sm:px-10 lg:px-16">
      <div ref={bg.ref} className="absolute inset-0" style={{ transform: `translateY(${bg.offset}px)` }}>
        <img src="/images/closing-abstract.jpg" alt="" className="h-[120%] w-full object-cover opacity-30 grayscale" />
      </div>
      <div className="absolute inset-0 bg-gradient-to-b from-black via-black/70 to-black" />
      <div className="grain absolute inset-0" />

      <div className="relative z-10 mx-auto max-w-4xl">
        <Reveal>
          <p className="font-display text-xs uppercase tracking-[0.5em] text-white/40">Closing Statement</p>
        </Reveal>
        <Reveal delay={150}>
          <h2 className="mt-10 font-display text-5xl font-medium leading-[1.08] tracking-tight sm:text-7xl">
            Good software isn't an accident. <span className="text-white/35">It's designed.</span>
          </h2>
        </Reveal>
        <Reveal delay={300}>
          <p className="mx-auto mt-10 max-w-xl text-base leading-relaxed text-white/60">
            PUIUX builds digital products with the same care at every stage — from the first
            sketch to the last line of code.
          </p>
        </Reveal>
      </div>

      <PageMeta index="16" label="Closing Statement" tone="light" />
    </section>
  );
}
