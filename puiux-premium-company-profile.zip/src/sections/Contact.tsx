import { Reveal } from "../components/Reveal";
import { Kicker, PlaceholderField, Divider } from "../components/ui";

const fields = [
  { label: "Website", value: "To be provided" },
  { label: "Email", value: "To be provided" },
  { label: "Phone", value: "To be provided" },
  { label: "Social", value: "To be provided" },
];

export function Contact() {
  return (
    <section id="contact" className="relative flex min-h-screen flex-col justify-between bg-black px-6 pb-10 pt-28 text-white sm:px-10 lg:px-16">
      <div>
        <Reveal>
          <Kicker tone="light">Contact Us</Kicker>
        </Reveal>
        <Reveal delay={100}>
          <h2 className="mt-10 max-w-3xl font-display text-5xl font-medium leading-[1.05] tracking-tight sm:text-7xl">
            Let's build what's next.
          </h2>
        </Reveal>
        <Reveal delay={200} className="mt-8 max-w-lg text-base leading-relaxed text-white/60">
          Reach out to discuss a product idea, an existing platform that needs work, or a
          long-term engineering partnership.
        </Reveal>

        <Divider tone="light" className="my-14" />

        <Reveal delay={250}>
          <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4">
            {fields.map((f) => (
              <div key={f.label}>
                <p className="font-display text-xs uppercase tracking-[0.3em] text-white/40">{f.label}</p>
                <p className="mt-3">
                  <PlaceholderField tone="light" label={f.value} />
                </p>
              </div>
            ))}
          </div>
        </Reveal>
      </div>

      <div className="mt-20 flex flex-col gap-4 border-t border-white/10 pt-8 text-[11px] uppercase tracking-[0.3em] text-white/40 sm:flex-row sm:items-center sm:justify-between">
        <span className="font-display text-sm tracking-[0.3em] text-white">PUIUX</span>
        <span>Software &amp; Digital Product Development Studio</span>
        <span>17 / 17</span>
        <span>© {new Date().getFullYear()} PUIUX. All rights reserved.</span>
      </div>
    </section>
  );
}
