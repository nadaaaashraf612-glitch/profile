import { Reveal } from "../components/Reveal";
import { GlassCard, Kicker, PageMeta, PlaceholderField } from "../components/ui";

const facts = [
  { label: "Founded", value: <PlaceholderField tone="light" label="To be confirmed" /> },
  { label: "Headquarters", value: <PlaceholderField tone="light" label="To be confirmed" /> },
  { label: "Studio Type", value: "Software & digital product development" },
  { label: "Core Disciplines", value: "Design, Engineering, Strategy" },
  { label: "Engagement Model", value: "Project-based & embedded teams" },
  { label: "Delivery Scope", value: "Web, mobile & custom platforms" },
];

export function Glance() {
  return (
    <section id="glance" className="relative flex min-h-screen flex-col justify-center overflow-hidden bg-black px-6 py-28 text-white sm:px-10 lg:px-16">
      <div className="grid grid-cols-1 gap-12 lg:grid-cols-12">
        <div className="lg:col-span-4">
          <Reveal>
            <Kicker tone="light">Company at a Glance</Kicker>
          </Reveal>
          <Reveal delay={100}>
            <h2 className="mt-8 font-display text-4xl font-medium leading-tight tracking-tight sm:text-5xl">
              A studio structured around three disciplines.
            </h2>
          </Reveal>
          <Reveal delay={200} className="mt-6 max-w-sm text-sm leading-relaxed text-white/60">
            Figures marked as pending reflect fields awaiting confirmed company data. All
            capability and service information below is accurate to PUIUX's current practice.
          </Reveal>
        </div>

        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:col-span-8">
          {facts.map((f, i) => (
            <Reveal key={f.label} delay={i * 80}>
              <GlassCard tone="dark" className="flex h-full flex-col justify-between p-7">
                <p className="font-display text-xs uppercase tracking-[0.3em] text-white/45">{f.label}</p>
                <p className="mt-6 font-display text-xl font-medium leading-snug">{f.value}</p>
              </GlassCard>
            </Reveal>
          ))}
        </div>
      </div>

      <PageMeta index="05" label="Company at a Glance" tone="light" />
    </section>
  );
}
