import { Reveal } from "../components/Reveal";
import { Kicker, PageMeta, GlassCard } from "../components/ui";

const pillars = [
  {
    title: "Business Understanding",
    copy: "We begin with goals, constraints and context — ensuring every design and engineering decision serves a real outcome.",
  },
  {
    title: "User-Centered Design",
    copy: "Interfaces are shaped around how people actually think and behave, validated through research and iteration.",
  },
  {
    title: "Technical Execution",
    copy: "Clean architecture and disciplined engineering turn validated design into stable, scalable software.",
  },
];

export function Approach() {
  return (
    <section id="approach" className="relative flex min-h-screen flex-col justify-center overflow-hidden bg-black px-6 py-28 text-white sm:px-10 lg:px-16">
      <Reveal>
        <Kicker tone="light">Our Approach</Kicker>
      </Reveal>

      <Reveal delay={100}>
        <h2 className="mt-8 max-w-4xl font-display text-4xl font-medium leading-[1.1] tracking-tight sm:text-6xl">
          Three disciplines, working as one continuous process.
        </h2>
      </Reveal>

      <div className="relative mt-20 grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="pointer-events-none absolute left-0 right-0 top-1/2 hidden h-px -translate-y-1/2 bg-white/10 lg:block" />
        {pillars.map((p, i) => (
          <Reveal key={p.title} delay={i * 150}>
            <GlassCard tone="dark" className="relative h-full p-8">
              <span className="font-display text-7xl font-semibold text-white/10">{`0${i + 1}`}</span>
              <h3 className="mt-6 font-display text-2xl font-medium tracking-tight">{p.title}</h3>
              <p className="mt-4 text-sm leading-relaxed text-white/65">{p.copy}</p>
            </GlassCard>
          </Reveal>
        ))}
      </div>

      <Reveal delay={450} className="mt-14 max-w-2xl border-t border-white/15 pt-8 text-base leading-relaxed text-white/70">
        None of the three stands alone. Business context informs design decisions; design
        decisions shape technical architecture; technical constraints, in turn, refine the
        product strategy. This loop — not a linear handoff — is how PUIUX works.
      </Reveal>

      <PageMeta index="07" label="Our Approach" tone="light" />
    </section>
  );
}
