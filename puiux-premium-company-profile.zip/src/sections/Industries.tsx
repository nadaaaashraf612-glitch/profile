import { Reveal } from "../components/Reveal";
import { industries } from "../data/content";
import { Kicker, PageMeta, Divider } from "../components/ui";

export function Industries() {
  return (
    <section id="industries" className="relative flex min-h-screen flex-col justify-center bg-[#fafaf8] px-6 py-28 text-black sm:px-10 lg:px-16">
      <div className="flex flex-col gap-6 sm:flex-row sm:items-end sm:justify-between">
        <Reveal>
          <Kicker>Industries We Serve</Kicker>
          <h2 className="mt-8 max-w-xl font-display text-5xl font-medium leading-tight tracking-tight sm:text-6xl">
            Focus areas across digital products.
          </h2>
        </Reveal>
        <Reveal delay={150} className="max-w-xs text-sm italic leading-relaxed text-black/50">
          Representative focus areas — refined further as project history is confirmed.
        </Reveal>
      </div>

      <Divider className="mt-12" />

      <div className="grid grid-cols-1 sm:grid-cols-2">
        {industries.map((ind, i) => (
          <Reveal key={ind} delay={(i % 4) * 90}>
            <div className="group flex items-center justify-between border-b border-black/10 py-6">
              <span className="font-display text-2xl font-medium tracking-tight transition group-hover:translate-x-2 sm:text-3xl">
                {ind}
              </span>
              <span className="font-display text-sm text-black/30">{String(i + 1).padStart(2, "0")}</span>
            </div>
          </Reveal>
        ))}
      </div>

      <PageMeta index="10" label="Industries We Serve" />
    </section>
  );
}
