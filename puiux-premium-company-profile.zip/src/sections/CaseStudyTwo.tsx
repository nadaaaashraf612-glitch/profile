import { Reveal } from "../components/Reveal";
import { Kicker, PageMeta, TagPill, GlassCard } from "../components/ui";

export function CaseStudyTwo() {
  return (
    <section id="case-02" className="relative flex min-h-screen flex-col justify-center overflow-hidden bg-black px-6 py-28 text-white sm:px-10 lg:px-16">
      <div className="absolute inset-y-0 right-0 hidden w-[42%] lg:block">
        <img
          src="/images/case-study-2.jpg"
          alt="On-demand marketplace app — illustrative placeholder mockup"
          className="mask-fade-b h-full w-full object-cover opacity-70 grayscale"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black via-black/40 to-transparent" />
      </div>

      <div className="relative z-10 grid grid-cols-1 gap-10 lg:grid-cols-12">
        <div className="lg:col-span-7">
          <Reveal>
            <Kicker tone="light">Case Study — 02</Kicker>
            <div className="mt-6 flex items-center gap-3">
              <TagPill tone="light">Illustrative Placeholder</TagPill>
              <TagPill tone="light">Mobile Application</TagPill>
            </div>
          </Reveal>

          <Reveal delay={100}>
            <h2 className="mt-6 max-w-2xl font-display text-5xl font-medium leading-[1.05] tracking-tight sm:text-6xl">
              On-Demand Marketplace App
            </h2>
          </Reveal>

          <Reveal delay={200} className="mt-10 grid max-w-2xl grid-cols-1 gap-6 sm:grid-cols-2">
            <GlassCard tone="dark" className="p-6">
              <p className="font-display text-xs uppercase tracking-[0.3em] text-white/45">Challenge</p>
              <p className="mt-3 text-sm leading-relaxed text-white/75">
                Connect buyers and independent sellers through a fast, trustworthy mobile
                experience from day one.
              </p>
            </GlassCard>
            <GlassCard tone="dark" className="p-6">
              <p className="font-display text-xs uppercase tracking-[0.3em] text-white/45">Solution</p>
              <p className="mt-3 text-sm leading-relaxed text-white/75">
                A native-feeling cross-platform app with streamlined onboarding, discovery and
                checkout flows.
              </p>
            </GlassCard>
            <GlassCard tone="dark" className="p-6">
              <p className="font-display text-xs uppercase tracking-[0.3em] text-white/45">Scope</p>
              <p className="mt-3 text-sm leading-relaxed text-white/75">
                Product design, iOS &amp; Android development, backend API integration.
              </p>
            </GlassCard>
            <GlassCard tone="dark" className="p-6">
              <p className="font-display text-xs uppercase tracking-[0.3em] text-white/45">Outcome</p>
              <p className="mt-3 text-sm italic leading-relaxed text-white/40">
                Verified results pending client approval for publication.
              </p>
            </GlassCard>
          </Reveal>
        </div>
      </div>

      <PageMeta index="13" label="Case Study — 02" tone="light" />
    </section>
  );
}
