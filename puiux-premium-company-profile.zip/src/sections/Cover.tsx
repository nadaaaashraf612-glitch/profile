import { useParallax } from "../hooks/useReveal";
import { PageMeta } from "../components/ui";

export function Cover() {
  const bg = useParallax<HTMLDivElement>(0.08);

  return (
    <section id="cover" className="relative flex min-h-screen flex-col overflow-hidden bg-black text-white">
      <div ref={bg.ref} className="absolute inset-0" style={{ transform: `translateY(${bg.offset}px)` }}>
        <img
          src="/images/hero-texture.jpg"
          alt=""
          className="h-[120%] w-full object-cover opacity-40 grayscale"
        />
      </div>
      <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/40 to-black" />
      <div className="grain absolute inset-0" />

      <div className="relative z-10 flex flex-1 flex-col px-6 pt-28 sm:px-10 sm:pt-32 lg:px-16">
        <div className="flex flex-col items-start justify-between gap-6 text-[11px] uppercase tracking-[0.35em] text-white/50 sm:flex-row sm:items-center">
          <span>Company Profile — Edition 2026</span>
          <span>Software &amp; Digital Product Studio</span>
        </div>

        <div className="relative mt-16 flex flex-1 flex-col justify-center sm:mt-20">
          <p className="mb-6 font-display text-sm uppercase tracking-[0.5em] text-white/40">Introducing</p>
          <h1 className="relative select-none font-display font-semibold leading-[0.82] tracking-tight">
            <span className="block text-[20vw] sm:text-[17vw] lg:text-[15vw]">PUIUX</span>
          </h1>
          <div className="mt-10 grid max-w-3xl grid-cols-1 gap-6 border-t border-white/15 pt-8 sm:grid-cols-[1fr_auto] sm:items-end">
            <p className="font-display text-xl font-light leading-snug text-white/80 sm:text-2xl">
              Considered software and digital products, designed and engineered with discipline.
            </p>
          </div>
        </div>

        <div className="mb-10 flex items-center justify-between text-[11px] uppercase tracking-[0.3em] text-white/40">
          <span className="hidden sm:inline">UI/UX · Web · Mobile · Custom Software</span>
          <span className="flex items-center gap-3">
            Scroll
            <span className="block h-8 w-px animate-pulse bg-white/50" />
          </span>
        </div>
      </div>

      <PageMeta index="01" label="Cover" tone="light" />
    </section>
  );
}
