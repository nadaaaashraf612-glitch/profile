import { Reveal } from "../components/Reveal";
import { qualityPoints } from "../data/content";
import { GlassCard, Kicker, PageMeta } from "../components/ui";

export function Quality() {
  return (
    <section id="quality" className="relative flex min-h-screen flex-col justify-center bg-[#fafaf8] px-6 py-28 text-black sm:px-10 lg:px-16">
      <div className="grid grid-cols-1 gap-14 lg:grid-cols-12">
        <div className="lg:col-span-4">
          <Reveal>
            <Kicker>Quality &amp; Collaboration</Kicker>
          </Reveal>
          <Reveal delay={100}>
            <h2 className="mt-8 font-display text-4xl font-medium leading-tight tracking-tight sm:text-5xl">
              Trust, built through process.
            </h2>
          </Reveal>
          <Reveal delay={200} className="mt-6 max-w-sm text-sm leading-relaxed text-black/60">
            Client testimonials and partnership logos will appear here once authorized by PUIUX
            and its partners. No quotes or affiliations are implied in their absence.
          </Reveal>
        </div>

        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:col-span-8">
          {qualityPoints.map((q, i) => (
            <Reveal key={q.title} delay={i * 100}>
              <GlassCard className="h-full border-black/10 bg-black/[0.02] p-7">
                <h3 className="font-display text-xl font-medium tracking-tight">{q.title}</h3>
                <p className="mt-3 text-sm leading-relaxed text-black/60">{q.copy}</p>
              </GlassCard>
            </Reveal>
          ))}
        </div>
      </div>

      <PageMeta index="15" label="Quality & Collaboration" />
    </section>
  );
}
