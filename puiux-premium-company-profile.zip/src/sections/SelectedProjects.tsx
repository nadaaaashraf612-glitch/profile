import { Reveal } from "../components/Reveal";
import { Kicker, PageMeta, TagPill } from "../components/ui";

const projects = [
  {
    img: "/images/case-study-1.jpg",
    title: "Enterprise SaaS Dashboard",
    type: "Web Platform · UI/UX + Engineering",
  },
  {
    img: "/images/case-study-2.jpg",
    title: "On-Demand Marketplace App",
    type: "Mobile Application · iOS & Android",
  },
  {
    img: "/images/projects-grid.jpg",
    title: "E-commerce Storefront",
    type: "Web Development · Custom Build",
  },
];

export function SelectedProjects() {
  return (
    <section id="projects" className="relative flex min-h-screen flex-col justify-center bg-black px-6 py-28 text-white sm:px-10 lg:px-16">
      <div className="flex flex-col gap-6 sm:flex-row sm:items-end sm:justify-between">
        <Reveal>
          <Kicker tone="light">Selected Projects</Kicker>
          <h2 className="mt-8 max-w-xl font-display text-5xl font-medium leading-tight tracking-tight sm:text-6xl">
            Representative product work.
          </h2>
        </Reveal>
        <Reveal delay={150} className="max-w-xs text-sm italic leading-relaxed text-white/50">
          Illustrative placeholders — shown pending final, approved case assets from PUIUX.
        </Reveal>
      </div>

      <div className="mt-16 grid grid-cols-1 gap-6 lg:grid-cols-3">
        {projects.map((p, i) => (
          <Reveal key={p.title} delay={i * 120}>
            <div className="group relative overflow-hidden rounded-2xl border border-white/10 bg-white/5">
              <div className="relative aspect-[4/5] overflow-hidden">
                <img
                  src={p.img}
                  alt={`${p.title} — illustrative placeholder mockup`}
                  className="h-full w-full object-cover grayscale transition duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/10 to-transparent" />
                <span className="absolute left-4 top-4 rounded-full border border-white/25 bg-black/50 px-3 py-1 text-[10px] uppercase tracking-[0.25em] text-white/70 backdrop-blur">
                  Placeholder
                </span>
              </div>
              <div className="absolute inset-x-0 bottom-0 p-6">
                <TagPill tone="light">{p.type}</TagPill>
                <h3 className="mt-3 font-display text-xl font-medium tracking-tight">{p.title}</h3>
              </div>
            </div>
          </Reveal>
        ))}
      </div>

      <PageMeta index="11" label="Selected Projects" tone="light" />
    </section>
  );
}
