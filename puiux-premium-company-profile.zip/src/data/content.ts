export const sectionIndex = [
  { id: "cover", label: "Cover" },
  { id: "opening", label: "Opening Statement" },
  { id: "who-we-are", label: "Who We Are" },
  { id: "vmv", label: "Vision, Mission & Values" },
  { id: "glance", label: "Company at a Glance" },
  { id: "services", label: "Our Services" },
  { id: "approach", label: "Our Approach" },
  { id: "process", label: "How We Work" },
  { id: "expertise", label: "Our Expertise" },
  { id: "industries", label: "Industries We Serve" },
  { id: "projects", label: "Selected Projects" },
  { id: "case-01", label: "Case Study — 01" },
  { id: "case-02", label: "Case Study — 02" },
  { id: "why", label: "Why PUIUX" },
  { id: "quality", label: "Quality & Collaboration" },
  { id: "closing", label: "Closing Statement" },
  { id: "contact", label: "Contact" },
] as const;

export type SectionId = (typeof sectionIndex)[number]["id"];

export const values = [
  {
    no: "01",
    title: "Clarity",
    copy: "We simplify complex problems into products that are easy to understand, build, and use.",
  },
  {
    no: "02",
    title: "Craft",
    copy: "Every interface, interaction and line of code is treated as a deliberate design decision.",
  },
  {
    no: "03",
    title: "Partnership",
    copy: "We work alongside our clients as an embedded team, not a detached vendor.",
  },
  {
    no: "04",
    title: "Rigor",
    copy: "Decisions are grounded in research, testing and technical discipline — not guesswork.",
  },
];

export const services = [
  {
    no: "01",
    title: "UI/UX & Product Design",
    copy: "Research-driven product design — from information architecture and wireframes to high-fidelity interfaces and design systems.",
    tags: ["User Research", "Wireframing", "Design Systems", "Prototyping"],
  },
  {
    no: "02",
    title: "Web Development",
    copy: "Fast, scalable, and maintainable web applications built with modern frameworks and clean architecture.",
    tags: ["Web Apps", "Marketing Sites", "CMS", "APIs"],
  },
  {
    no: "03",
    title: "Mobile Applications",
    copy: "Native and cross-platform mobile apps engineered for performance, stability and a refined user experience.",
    tags: ["iOS", "Android", "Cross-Platform", "App Store Delivery"],
  },
  {
    no: "04",
    title: "Custom Software",
    copy: "Bespoke platforms, internal tools and automation systems designed around real operational workflows.",
    tags: ["SaaS Platforms", "Dashboards", "Integrations", "Automation"],
  },
  {
    no: "05",
    title: "Product Strategy",
    copy: "Shaping the right product before building it — scoping, roadmapping, and validating direction with stakeholders.",
    tags: ["Discovery", "Roadmapping", "MVP Scoping"],
  },
  {
    no: "06",
    title: "Support & Evolution",
    copy: "Ongoing maintenance, iteration and performance monitoring once a product is live in the market.",
    tags: ["Maintenance", "QA", "Optimization"],
  },
];

export const processSteps = [
  {
    no: "01",
    title: "Discovery",
    copy: "Understanding business goals, users and constraints before any design or engineering begins.",
  },
  {
    no: "02",
    title: "Planning",
    copy: "Defining scope, architecture and success metrics into a clear, shared roadmap.",
  },
  {
    no: "03",
    title: "UX / UI Design",
    copy: "Structuring flows and crafting interfaces validated through iteration, not assumption.",
  },
  {
    no: "04",
    title: "Development",
    copy: "Building on clean, scalable foundations with regular checkpoints and visible progress.",
  },
  {
    no: "05",
    title: "Testing",
    copy: "Rigorous functional, usability and performance testing before anything reaches real users.",
  },
  {
    no: "06",
    title: "Launch",
    copy: "Coordinated release across platforms with monitoring in place from day one.",
  },
  {
    no: "07",
    title: "Support",
    copy: "Continued iteration, maintenance and optimization as the product and its users evolve.",
  },
];

export const expertise = [
  {
    group: "Design",
    items: ["Figma", "Design Systems", "Motion & Micro-interaction", "Accessibility (WCAG)"],
  },
  {
    group: "Frontend",
    items: ["React", "Next.js", "TypeScript", "Tailwind CSS"],
  },
  {
    group: "Mobile",
    items: ["React Native", "Swift", "Kotlin", "Flutter"],
  },
  {
    group: "Backend & Cloud",
    items: ["Node.js", "REST & GraphQL APIs", "Cloud Infrastructure", "CI / CD"],
  },
];

export const industries = [
  "Fintech & Payments",
  "E-commerce & Retail",
  "Healthtech",
  "Logistics & Mobility",
  "Education",
  "Enterprise SaaS",
  "Real Estate & PropTech",
  "Hospitality",
];

export const whyPoints = [
  {
    no: "01",
    title: "Design-Led Engineering",
    copy: "Design and development are treated as one discipline, not separate stages handed off between teams.",
  },
  {
    no: "02",
    title: "Senior Involvement",
    copy: "Experienced designers and engineers stay close to the work from kickoff through launch.",
  },
  {
    no: "03",
    title: "Transparent Process",
    copy: "Clear scope, visible progress and honest communication at every stage of the engagement.",
  },
  {
    no: "04",
    title: "Built to Scale",
    copy: "Architecture and interfaces designed to grow with the business, not just satisfy a launch date.",
  },
];

export const qualityPoints = [
  {
    title: "Communication",
    copy: "Structured check-ins, shared documentation and a single point of contact throughout the engagement.",
  },
  {
    title: "Quality Assurance",
    copy: "Dedicated testing cycles across devices, browsers and edge cases before every release.",
  },
  {
    title: "Delivery Discipline",
    copy: "Milestone-based delivery with clear scope, timelines and visible progress tracking.",
  },
  {
    title: "Ongoing Support",
    copy: "Post-launch monitoring, iteration and support plans tailored to each product's needs.",
  },
];
